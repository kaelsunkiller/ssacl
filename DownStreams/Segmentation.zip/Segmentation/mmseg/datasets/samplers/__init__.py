# Copyright (c) OpenMMLab. All rights reserved.
from .distributed_sampler import DistributedSampler,SIIMDistributedSampler

__all__ = ['DistributedSampler','SIIMDistributedSampler']
