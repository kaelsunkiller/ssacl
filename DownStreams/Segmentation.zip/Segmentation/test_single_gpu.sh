PYTHONPATH="$(dirname $0)/..":$PYTHONPATH \
CUDA_VISIBLE_DEVICES=$1 python tools/test.py \
    configs/ssacl/upernet_mrm-base_fp16_8x2_512x512_160k_siim.py \
    output_ssacl/best_Dice.front_iter_153000.pth \
    --eval mDice --show --show-dir output_images_ssacl --opacity 0.5