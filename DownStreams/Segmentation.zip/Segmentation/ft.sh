bash tools/dist_train.sh \
    configs/ssacl/upernet_mrm-base_fp16_8x2_512x512_160k_siim.py 4,5,6,7 \
    --work-dir ./output_ssacl/ --seed 0  --deterministic \
    --cfg-options model.backbone.pretrained=/path/to/pretrained_weights/ssacl-best.pth

